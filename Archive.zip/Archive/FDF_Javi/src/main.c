/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: antdelga <antdelga@student.42malaga.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/30 20:43:38 by javiersa          #+#    #+#             */
/*   Updated: 2023/04/26 00:44:09 by antdelga         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fdf.h"

int32_t	ft_w_center(const uint32_t n1, const uint32_t n2)
{
	if (n1 > n2)
		return ((n1 - n2) / 2);
	return ((n2 - n1) / 2);
}

void	draw_listpoints(t_fdfvariables *points, int tam, int cont_lines)
{
	int	index;

	index = -1;
	while (++index < tam * cont_lines)
	{
		ft_printf("Index: %d\n", index);
		ft_printf("Z: %d\n", points->map[index].z);
		// ft_printf("R: %d\n", points->map[index].r);
		// ft_printf("G: %d\n", points->map[index].g);
		// ft_printf("B: %d\n", points->map[index].b);
		// ft_printf("T: %d\n", points->map[index].a);
		ft_printf("Xiso: %d\n", points->map[index].x_draw);
		ft_printf("Yiso: %d\n\n", points->map[index].y_draw);
	}
}

int32_t	main(int narg, char **argv)
{
	t_fdfvariables	fdf;

	if (narg != 2 || !argv[1])
		return (1);
	ft_map_construct(argv[1], &fdf);
	/* HASTA AQUI OK */

	draw_listpoints(&fdf, fdf.map_width, fdf.map_height);
	// ft_printf("%d\n%d\n", fdf.window_width, fdf.window_height);

	/* PARA MANEJAR LA IMAGEN, VENTANA, ETC */
	fdf.mlx = mlx_init(WIDTH, HEIGHT, "FDF - javiersa", true);
	if (!fdf.mlx)
		ft_error("MLX INIT FAIL.", 1, fdf.map);
	
	/* PARA PINTAR */
	fdf.img = mlx_new_image(fdf.mlx, fdf.window_width, fdf.window_height);
	if (!fdf.img)
		ft_error("MLX NEW IMAGE FAIL.", 1, fdf.map);
	
	ft_picasso(&fdf);
	
	/* CENTRADO Y MENÚS, CREO */
	if (mlx_image_to_window(fdf.mlx, fdf.img, \
	ft_w_center(WIDTH, fdf.img->width), ft_w_center(HEIGHT, fdf.img->height)))
		ft_error("MLX IMAGE TO WINDOW FAIL.", 1, fdf.map);
	ft_menu(&fdf);

	/* HOOKS */
	mlx_loop_hook(fdf.mlx, &keyboard_hooks, (void *)&fdf);
	mlx_scroll_hook(fdf.mlx, &scroll_hook, (void *)&fdf);
	mlx_cursor_hook(fdf.mlx, &cursor_hook, (void *)&fdf);
	mlx_loop(fdf.mlx);
	ft_multiple_free(1, fdf.map);
	mlx_delete_image(fdf.mlx, fdf.img);
	mlx_terminate(fdf.mlx);

	return (EXIT_SUCCESS);
}
