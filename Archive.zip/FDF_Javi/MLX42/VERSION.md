# Version

## Current Version: 2.2.0

---

## Latest: <img style="margin: 0px 0px -3px 0px" src="https://img.shields.io/github/v/tag/codam-coding-college/MLX42?label=Version" alt="License GPL2.0"> <img style="margin: 0px 0px -3px 0px" src="https://github.com/codam-coding-college/MLX42/actions/workflows/ci.yml/badge.svg" alt="Build">